Ultimate Loot Editor server half.

`maps/<MapFolder>/*.json` is where the client plugin writes shareable loot edits.
